BH A D E X PLUGS — Paystack backend starter

This project includes a Node/Express backend. It is not live until deployed and configured.

1) Install Node.js 20+.
2) In this folder run: npm install
3) Copy .env.example to .env and set PAYSTACK_SECRET_KEY (test key initially) and SITE_URL.
4) Run: npm start
5) Put the provided frontend HTML in a folder named "public" as index.html.
   (Rename public.html to public/index.html.)
6) Deploy on a Node hosting provider that supports HTTPS and environment variables.
7) Test in Paystack test mode before switching to live credentials.
8) Set Paystack webhook URL to https://YOUR_DOMAIN/api/paystack/webhook

Security:
- Keep secret key only in server environment variables, never frontend/source repository.
- Amounts are chosen from server-side product list, not trusted from browser.
- This starter verifies callback status/currency/product amount. For a production shop, add persistent orders,
  idempotent fulfillment, delivery workflow, and webhook processing in a database.
- This sample is a technical starter; have an adult business owner/guardian manage account, payments,
  customer data, and compliance. Confirm each subscription is legitimately resold/authorized.
