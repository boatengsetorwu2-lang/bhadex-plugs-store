import express from "express";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import dotenv from "dotenv";
import crypto from "crypto";
import path from "path";
import { fileURLToPath } from "url";
dotenv.config();
const app=express();
const __dirname=path.dirname(fileURLToPath(import.meta.url));
app.use(helmet({contentSecurityPolicy:false}));
app.use(express.json({limit:"20kb"}));
app.use(rateLimit({windowMs:60_000,max:30}));
app.use(express.static(path.join(__dirname,"public")));
const products={
 canva:{name:"Canva Pro",amount:4500},
 spotify:{name:"Spotify Premium",amount:3500},
 youtube:{name:"YouTube Premium",amount:5000},
 chatgpt:{name:"ChatGPT Plus",amount:22000},
 m365:{name:"Microsoft 365",amount:9000},
 googleone:{name:"Google One",amount:3500}
};
const secret=process.env.PAYSTACK_SECRET_KEY;
const site=process.env.SITE_URL;
if(!secret||!site)console.warn("Set PAYSTACK_SECRET_KEY and SITE_URL in environment variables.");
app.post("/api/paystack/initialize",async(req,res)=>{
 try{
  const {productId,name,email}=req.body||{};
  const product=products[productId];
  if(!product)return res.status(400).json({error:"Choose a valid product."});
  if(typeof name!=="string"||name.trim().length<2||name.length>100)return res.status(400).json({error:"Enter a valid name."});
  if(typeof email!=="string"||! /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))return res.status(400).json({error:"Enter a valid email."});
  const reference="bhadex_"+crypto.randomUUID().replaceAll("-","");
  const response=await fetch("https://api.paystack.co/transaction/initialize",{
   method:"POST",headers:{Authorization:`Bearer ${secret}`,"Content-Type":"application/json"},
   body:JSON.stringify({email,amount:String(product.amount),currency:"GHS",reference,callback_url:`${site}/payment/callback`,channels:["card","mobile_money"],metadata:{product_id:productId,product_name:product.name,customer_name:name.trim()}})
  });
  const data=await response.json();
  if(!response.ok||!data.status)throw new Error(data.message||"Paystack initialization failed.");
  res.json({authorization_url:data.data.authorization_url,reference:data.data.reference});
 }catch(e){console.error(e.message);res.status(502).json({error:"Payment could not be initialized. Please try again."})}
});
app.get("/payment/callback",async(req,res)=>{
 const ref=String(req.query.reference||"");
 if(!ref||ref.length>100)return res.status(400).send("Missing payment reference.");
 try{
  const r=await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(ref)}`,{headers:{Authorization:`Bearer ${secret}`}});
  const v=await r.json();
  if(!r.ok||!v.status||v.data.status!=="success"||v.data.currency!=="GHS")return res.status(400).send("Payment not confirmed. Please contact support with your reference.");
  const product=products[v.data.metadata?.product_id];
  if(!product||Number(v.data.amount)!==product.amount)return res.status(400).send("Payment amount could not be verified.");
  res.send(`<html><meta name="viewport" content="width=device-width"><body style="font-family:system-ui;background:#080b16;color:white;padding:40px"><h1>Payment confirmed ✓</h1><p>Reference: ${ref.replace(/[<>&"]/g,"")}</p><p>Your payment was verified. Please follow the delivery instructions from Bhadex Plugs.</p><a style="color:#25d9c3" href="/">Back to store</a></body></html>`);
 }catch{res.status(502).send("Could not verify payment at this time. Please contact support before retrying.")}
});
app.post("/api/paystack/webhook",(req,res)=>{
 const signature=req.headers["x-paystack-signature"];
 const hash=crypto.createHmac("sha512",secret).update(JSON.stringify(req.body)).digest("hex");
 if(!signature||!crypto.timingSafeEqual(Buffer.from(signature),Buffer.from(hash))){return res.sendStatus(401)}
 if(req.body.event==="charge.success"){console.log("Verified webhook event received for",req.body.data.reference)}
 res.sendStatus(200);
});
app.get("/health",(_,res)=>res.json({ok:true}));
const port=process.env.PORT||3000;app.listen(port,()=>console.log(`Bhadex Plugs server listening on ${port}`));
